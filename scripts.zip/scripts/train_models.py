#!/usr/bin/env python3
"""Train CNNs on splits/train|val|test. Prefer: python scripts/train_models.py"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from politician_cnn.train import main

if __name__ == "__main__":
    main()
