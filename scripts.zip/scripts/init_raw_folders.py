"""Create dataset/raw/<slug>/ folders from configs/classes.yaml."""
from __future__ import annotations

import argparse
from pathlib import Path

import yaml


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--classes",
        type=Path,
        default=root / "configs" / "classes.yaml",
        help="YAML with `classes: [{slug, display_name}, ...]`",
    )
    ap.add_argument(
        "--raw-root",
        type=Path,
        default=root / "dataset" / "raw",
        help="Where per-class image folders will be created",
    )
    args = ap.parse_args()

    cfg = yaml.safe_load(args.classes.read_text(encoding="utf-8"))
    classes = cfg.get("classes") or []
    if not classes:
        raise SystemExit("No classes found in YAML")

    args.raw_root.mkdir(parents=True, exist_ok=True)
    for c in classes:
        slug = c["slug"]
        p = args.raw_root / slug
        p.mkdir(parents=True, exist_ok=True)
        gitkeep = p / ".gitkeep"
        if not gitkeep.exists():
            gitkeep.write_text("", encoding="utf-8")
        print(f"OK {p}")

    print(f"\nCreated {len(classes)} folders under {args.raw_root}")
    print("Drop face images into each folder, then run verify_counts.py and split_dataset.py")


if __name__ == "__main__":
    main()
