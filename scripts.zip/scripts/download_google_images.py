"""
Download images from Google *via supported APIs* (not HTML scraping — that violates Google ToS).

Providers:
  1) google_cse — Google Custom Search JSON API (searchType=image). Requires API key + CX.
     Setup: https://developers.google.com/custom-search/v1/overview
            https://programmablesearchengine.google.com/ (create engine, enable Image search, "Search the entire web")

  2) serpapi — SerpApi Google Images engine (paid free tier; https://serpapi.com/). Set SERPAPI_API_KEY.

You are responsible for copyright and dataset ethics; use only images you have rights to use in your report.

Examples:
  set GOOGLE_API_KEY=...
  set GOOGLE_CSE_ID=...
  python scripts/download_google_images.py --provider google_cse --replace --max-per-class 90

  set SERPAPI_API_KEY=...
  python scripts/download_google_images.py --provider serpapi --replace --max-per-class 90
"""
from __future__ import annotations

import argparse
import hashlib
import os
import re
import time
from pathlib import Path
from urllib.parse import urlparse

import requests
import yaml

IMAGE_EXT = {".jpg", ".jpeg", ".png", ".webp"}
GOOGLE_CSE_URL = "https://customsearch.googleapis.com/customsearch/v1"
SERPAPI_URL = "https://serpapi.com/search.json"


def safe_slug(s: str) -> str:
    return re.sub(r"[^\w\-]+", "_", s, flags=re.UNICODE)[:120]


def clear_images(folder: Path) -> None:
    for p in folder.iterdir():
        if p.is_file() and p.suffix.lower() in IMAGE_EXT:
            p.unlink()


def extension_from_url(url: str, content_type: str | None) -> str:
    path = urlparse(url).path.lower()
    for ext in (".jpg", ".jpeg", ".png", ".webp"):
        if path.endswith(ext):
            return ext
    if content_type:
        ct = content_type.split(";")[0].strip().lower()
        if "jpeg" in ct or "jpg" in ct:
            return ".jpg"
        if "png" in ct:
            return ".png"
        if "webp" in ct:
            return ".webp"
    return ".jpg"


def download_url(session: requests.Session, url: str, dest: Path, min_bytes: int, max_bytes: int) -> bool:
    try:
        r = session.get(url, timeout=45, stream=True, headers={"User-Agent": "Mozilla/5.0 (compatible; MLOpsCourseDataset/1.0)"})
        r.raise_for_status()
        data = r.content
        if len(data) < min_bytes or len(data) > max_bytes:
            return False
        dest.write_bytes(data)
        return True
    except (requests.RequestException, OSError):
        return False


def collect_urls_google_cse(
    session: requests.Session,
    api_key: str,
    cx: str,
    query: str,
    max_results: int,
    pause: float,
) -> list[str]:
    urls: list[str] = []
    start = 1
    while len(urls) < max_results and start <= 91:
        num = min(10, max_results - len(urls))
        params = {
            "key": api_key,
            "cx": cx,
            "q": query,
            "searchType": "image",
            "num": num,
            "start": start,
            "imgType": "face",
            "safe": "active",
        }
        r = session.get(GOOGLE_CSE_URL, params=params, timeout=30)
        r.raise_for_status()
        data = r.json()
        items = data.get("items") or []
        for it in items:
            link = it.get("link")
            if link and link.startswith(("http://", "https://")):
                urls.append(link)
        if not items:
            break
        start += 10
        time.sleep(pause)
    return urls[:max_results]


def collect_urls_serpapi(
    session: requests.Session,
    api_key: str,
    query: str,
    max_results: int,
    pause: float,
) -> list[str]:
    """SerpApi google_images: paginate with ijn (page index)."""
    urls: list[str] = []
    ijn = 0
    while len(urls) < max_results and ijn <= 10:
        params = {
            "engine": "google_images",
            "q": query,
            "api_key": api_key,
            "ijn": ijn,
        }
        r = session.get(SERPAPI_URL, params=params, timeout=45)
        r.raise_for_status()
        data = r.json()
        results = data.get("images_results") or []
        if not results:
            break
        for it in results:
            u = it.get("original") or it.get("thumbnail")
            if u and u.startswith(("http://", "https://")):
                urls.append(u)
            if len(urls) >= max_results:
                return urls[:max_results]
        ijn += 1
        time.sleep(pause)
    return urls[:max_results]


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--classes", type=Path, default=root / "configs" / "classes.yaml")
    ap.add_argument("--raw-root", type=Path, default=root / "dataset" / "raw")
    ap.add_argument("--provider", choices=("google_cse", "serpapi"), default="google_cse")
    ap.add_argument("--max-per-class", type=int, default=90)
    ap.add_argument(
        "--replace",
        action="store_true",
        help="Delete existing jpg/png/webp in each raw class folder before downloading.",
    )
    ap.add_argument("--pause", type=float, default=0.4, help="Seconds between API / download calls.")
    ap.add_argument("--min-bytes", type=int, default=2_000)
    ap.add_argument("--max-bytes", type=int, default=8_000_000)
    args = ap.parse_args()

    api_key = os.environ.get("GOOGLE_API_KEY")
    cx = os.environ.get("GOOGLE_CSE_ID") or os.environ.get("GOOGLE_SEARCH_ENGINE_ID")
    serp_key = os.environ.get("SERPAPI_API_KEY")

    if args.provider == "google_cse" and (not api_key or not cx):
        raise SystemExit(
            "For --provider google_cse set environment variables:\n"
            "  GOOGLE_API_KEY\n"
            "  GOOGLE_CSE_ID   (Programmable Search Engine ID / cx)\n"
            "See: https://developers.google.com/custom-search/v1/introduction"
        )
    if args.provider == "serpapi" and not serp_key:
        raise SystemExit("For --provider serpapi set SERPAPI_API_KEY (https://serpapi.com/).")

    cfg = yaml.safe_load(args.classes.read_text(encoding="utf-8"))
    rows = cfg.get("classes") or []
    session = requests.Session()

    for row in rows:
        slug = row["slug"]
        display = row.get("display_name", slug)
        query = row.get("google_query") or f"{display} face portrait"
        dest_dir = args.raw_root / slug
        dest_dir.mkdir(parents=True, exist_ok=True)
        if args.replace:
            clear_images(dest_dir)

        if args.provider == "google_cse":
            assert api_key and cx
            urls = collect_urls_google_cse(
                session, api_key, cx, query, args.max_per_class, args.pause
            )
        else:
            urls = collect_urls_serpapi(session, serp_key, query, args.max_per_class, args.pause)

        saved = 0
        for u in urls:
            h = hashlib.sha256(u.encode("utf-8")).hexdigest()[:10]
            ext = extension_from_url(u, None)
            out = dest_dir / f"g_{safe_slug(slug)}_{h}{ext}"
            if out.exists():
                saved += 1
                continue
            if download_url(session, u, out, args.min_bytes, args.max_bytes):
                saved += 1
            time.sleep(args.pause)
        print(f"[{slug}] query={query!r} downloaded_ok={saved} -> {dest_dir}")

    print("\nNext: inspect/delete bad images, then: python scripts/verify_counts.py")
    print("Then: python scripts/split_dataset.py --clean")


if __name__ == "__main__":
    main()
