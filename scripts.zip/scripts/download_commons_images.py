"""
Download images from Wikimedia Commons into dataset/raw/<slug>/.

Uses the official MediaWiki API (https://commons.wikimedia.org/wiki/API).
Follow https://foundation.wikimedia.org/wiki/Policy:User-Agent_policy — pass
--contact-url or set COMMONS_CONTACT_URL so your requests identify you.

Typical workflow:
  python scripts/init_raw_folders.py --classes configs/classes.yaml
  python scripts/download_commons_images.py --classes configs/classes.yaml --max-per-class 120
  python scripts/verify_counts.py

Supplement with manual downloads if a category has too few usable faces.
"""
from __future__ import annotations

import argparse
import hashlib
import random
import re
import time
from pathlib import Path
from typing import Any

import requests
import yaml

API = "https://commons.wikimedia.org/w/api.php"
IMAGE_MIMES = {"image/jpeg", "image/png", "image/webp", "image/gif"}
SKIP_EXT = {".svg", ".tif", ".tiff", ".pdf", ".djvu", ".ogg", ".webm", ".mp3"}


def norm_category(name: str) -> str:
    name = name.strip()
    if not name.lower().startswith("category:"):
        return "Category:" + name
    return name


def session_from_args(contact: str | None) -> requests.Session:
    contact = contact or ""
    if not contact.strip():
        raise SystemExit(
            "Wikimedia requires a descriptive User-Agent with contact info. "
            "Pass --contact-url https://your.repo.or/email or set COMMONS_CONTACT_URL."
        )
    s = requests.Session()
    s.headers.update(
        {
            "User-Agent": f"PakPoliticianCourseDataset/1.0 ({contact})",
            "Accept": "application/json",
        }
    )
    return s


def api_get(
    s: requests.Session,
    params: dict[str, Any],
    *,
    retries: int = 5,
    backoff: float = 1.6,
) -> dict[str, Any]:
    last: Exception | None = None
    for attempt in range(retries):
        try:
            r = s.get(API, params={**params, "format": "json"}, timeout=60)
            r.raise_for_status()
            return r.json()
        except (requests.RequestException, OSError) as e:
            last = e
            sleep = backoff**attempt + random.uniform(0, 0.35)
            time.sleep(min(sleep, 20.0))
    assert last is not None
    raise last


def iter_category_files(
    s: requests.Session, category_title: str, limit: int
) -> list[str]:
    """Return up to `limit` file page titles (File:...)."""
    titles: list[str] = []
    cont: dict[str, str] | None = None
    while len(titles) < limit:
        params: dict[str, Any] = {
            "action": "query",
            "list": "categorymembers",
            "cmtitle": norm_category(category_title),
            "cmtype": "file",
            "cmlimit": min(500, limit - len(titles)),
        }
        if cont:
            params.update(cont)
        data = api_get(s, params)
        batch = data.get("query", {}).get("categorymembers", [])
        for m in batch:
            t = m.get("title") or ""
            if t.startswith("File:"):
                titles.append(t)
            if len(titles) >= limit:
                return titles
        cont = data.get("continue")
        if not cont:
            break
        time.sleep(0.2)
    return titles


def iter_search_files(
    s: requests.Session, search: str, limit: int
) -> list[str]:
    """Namespace 6 = File on Commons."""
    titles: list[str] = []
    cont: dict[str, str] | None = None
    while len(titles) < limit:
        params: dict[str, Any] = {
            "action": "query",
            "list": "search",
            "srsearch": search,
            "srnamespace": 6,
            "srlimit": min(50, limit - len(titles)),
        }
        if cont:
            params.update(cont)
        data = api_get(s, params)
        batch = data.get("query", {}).get("search", [])
        for m in batch:
            t = m.get("title") or ""
            if t.startswith("File:"):
                titles.append(t)
            if len(titles) >= limit:
                return titles
        cont = data.get("continue")
        if not cont:
            break
        time.sleep(0.2)
    return titles


def chunk(lst: list[str], n: int) -> list[list[str]]:
    return [lst[i : i + n] for i in range(0, len(lst), n)]


def fetch_imageinfo(
    s: requests.Session, file_titles: list[str]
) -> dict[str, dict[str, Any]]:
    out: dict[str, dict[str, Any]] = {}
    for group in chunk(file_titles, 40):
        data = api_get(
            s,
            {
                "action": "query",
                "titles": "|".join(group),
                "prop": "imageinfo",
                "iiprop": "url|mime|size|metadata",
            },
        )
        pages = data.get("query", {}).get("pages", {})
        for _pid, page in pages.items():
            title = page.get("title")
            infos = page.get("imageinfo") or []
            if title and infos:
                out[title] = infos[0]
        time.sleep(0.2)
    return out


def safe_name(title: str) -> str:
    base = title.replace("File:", "")
    base = re.sub(r"[^\w\-.]+", "_", base, flags=re.UNICODE)
    return base[:180] if len(base) > 180 else base


def download_one(
    s: requests.Session,
    url: str,
    dest: Path,
    min_bytes: int,
    max_bytes: int,
    *,
    retries: int = 4,
) -> bool:
    last: Exception | None = None
    for attempt in range(retries):
        try:
            r = s.get(url, stream=True, timeout=120)
            r.raise_for_status()
            data = r.content
            if len(data) < min_bytes or len(data) > max_bytes:
                return False
            dest.write_bytes(data)
            return True
        except (requests.RequestException, OSError) as e:
            last = e
            time.sleep(0.5 * (attempt + 1))
    return False


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--classes", type=Path, default=root / "configs" / "classes.yaml")
    ap.add_argument("--raw-root", type=Path, default=root / "dataset" / "raw")
    ap.add_argument("--max-per-class", type=int, default=120)
    ap.add_argument("--min-width", type=int, default=160)
    ap.add_argument("--min-bytes", type=int, default=4_000)
    ap.add_argument("--max-bytes", type=int, default=12_000_000)
    ap.add_argument("--sleep", type=float, default=0.35, help="Delay between file downloads")
    ap.add_argument(
        "--contact-url",
        default=None,
        help="Shown in User-Agent (repo URL or mailto). Overrides COMMONS_CONTACT_URL.",
    )
    args = ap.parse_args()

    import os

    contact = args.contact_url or os.environ.get("COMMONS_CONTACT_URL")
    s = session_from_args(contact)

    cfg = yaml.safe_load(args.classes.read_text(encoding="utf-8"))
    rows = cfg.get("classes") or []
    if not rows:
        raise SystemExit("No classes in YAML")

    args.raw_root.mkdir(parents=True, exist_ok=True)

    for row in rows:
        slug = row["slug"]
        cat = row.get("commons_category")
        search = row.get("commons_search")
        if not cat and not search:
            print(f"[skip] {slug}: set commons_category or commons_search in YAML")
            continue

        dest_dir = args.raw_root / slug
        dest_dir.mkdir(parents=True, exist_ok=True)

        titles: list[str] = []
        if cat:
            titles.extend(iter_category_files(s, cat, args.max_per_class))
        if search and len(titles) < args.max_per_class:
            need = args.max_per_class - len(titles)
            extra = iter_search_files(s, search, need + 20)
            seen = set(titles)
            for t in extra:
                if t not in seen:
                    titles.append(t)
                    seen.add(t)
                if len(titles) >= args.max_per_class:
                    break

        titles = titles[: args.max_per_class]
        if not titles:
            print(f"[warn] {slug}: no file titles from API")
            continue

        info = fetch_imageinfo(s, titles)
        saved = 0
        for title in titles:
            meta = info.get(title)
            if not meta:
                continue
            mime = (meta.get("mime") or "").lower()
            if mime not in IMAGE_MIMES:
                continue
            url = meta.get("url")
            if not url:
                continue
            w = meta.get("width")
            if isinstance(w, int) and w < args.min_width:
                continue

            ext = Path(url.split("?", 1)[0]).suffix.lower() or ".jpg"
            if ext in SKIP_EXT:
                continue

            h = hashlib.sha256(title.encode("utf-8")).hexdigest()[:12]
            fname = f"{safe_name(title)}_{h}{ext}"
            dest = dest_dir / fname
            if dest.exists():
                saved += 1
                continue
            try:
                if download_one(s, url, dest, args.min_bytes, args.max_bytes):
                    saved += 1
            except OSError:
                dest.unlink(missing_ok=True)
            except requests.RequestException:
                pass
            time.sleep(args.sleep)

        print(f"[done] {slug}: saved {saved} images under {dest_dir}")


if __name__ == "__main__":
    main()
