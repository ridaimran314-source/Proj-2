"""
Stratified split: dataset/raw/<class>/* -> splits/train|val|test (75/15/10) by default.
Run only after verify_counts.py passes.
"""
from __future__ import annotations

import argparse
import random
import shutil
from pathlib import Path

import yaml

IMAGE_EXT = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}


def list_images(folder: Path) -> list[Path]:
    files: list[Path] = []
    for f in sorted(folder.rglob("*")):
        if f.is_file() and f.suffix.lower() in IMAGE_EXT:
            files.append(f)
    return files


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    ap = argparse.ArgumentParser()
    ap.add_argument("--classes", type=Path, default=root / "configs" / "classes.yaml")
    ap.add_argument("--raw-root", type=Path, default=root / "dataset" / "raw")
    ap.add_argument(
        "--out-root",
        type=Path,
        default=root / "splits",
        help="Root containing train/, val/, test/ class folders (default: project splits/).",
    )
    ap.add_argument("--train", type=float, default=0.75)
    ap.add_argument("--val", type=float, default=0.15)
    ap.add_argument("--test", type=float, default=0.10)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument(
        "--clean",
        action="store_true",
        help="Remove existing train/val/test under out-root before copying",
    )
    args = ap.parse_args()

    if abs(args.train + args.val + args.test - 1.0) > 1e-6:
        raise SystemExit("train + val + test must sum to 1.0")

    cfg = yaml.safe_load(args.classes.read_text(encoding="utf-8"))
    slugs = [c["slug"] for c in cfg.get("classes") or []]
    if not slugs:
        raise SystemExit("No classes in YAML")

    train_d = args.out_root / "train"
    val_d = args.out_root / "val"
    test_d = args.out_root / "test"

    if args.clean:
        for split in (train_d, val_d, test_d):
            if split.exists():
                shutil.rmtree(split)

    rng = random.Random(args.seed)

    for slug in slugs:
        src_dir = args.raw_root / slug
        if not src_dir.is_dir():
            raise SystemExit(f"Missing raw folder: {src_dir}")

        imgs = list_images(src_dir)
        if not imgs:
            raise SystemExit(f"No images in {src_dir}")

        rng.shuffle(imgs)
        n = len(imgs)
        n_train = int(round(n * args.train))
        n_val = int(round(n * args.val))
        # assign remainder to test
        n_test = n - n_train - n_val
        if n_test < 0:
            raise SystemExit("Split rounding error; adjust ratios or counts")

        splits = [
            ("train", imgs[:n_train]),
            ("val", imgs[n_train : n_train + n_val]),
            ("test", imgs[n_train + n_val :]),
        ]

        for name, subset in splits:
            dest_root = args.out_root / name / slug
            dest_root.mkdir(parents=True, exist_ok=True)
            for i, fp in enumerate(subset):
                dest = dest_root / f"{slug}_{i:04d}{fp.suffix.lower()}"
                shutil.copy2(fp, dest)
            print(f"{slug} -> {name}: {len(subset)}")

    print(f"\nDone. Outputs under {args.out_root}/train|val|test")


if __name__ == "__main__":
    main()
