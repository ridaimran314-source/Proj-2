"""Check minimum images per class under dataset/raw (default: 80)."""
from __future__ import annotations

import argparse
from pathlib import Path

import yaml

IMAGE_EXT = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".gif"}


def count_images(folder: Path) -> int:
    n = 0
    for f in folder.rglob("*"):
        if f.is_file() and f.suffix.lower() in IMAGE_EXT:
            n += 1
    return n


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    ap = argparse.ArgumentParser()
    ap.add_argument("--classes", type=Path, default=root / "configs" / "classes.yaml")
    ap.add_argument("--raw-root", type=Path, default=root / "dataset" / "raw")
    ap.add_argument("--min-per-class", type=int, default=80)
    args = ap.parse_args()

    cfg = yaml.safe_load(args.classes.read_text(encoding="utf-8"))
    classes = [c["slug"] for c in cfg.get("classes") or []]
    if not classes:
        raise SystemExit("No classes in YAML")

    bad: list[tuple[str, int]] = []
    for slug in classes:
        d = args.raw_root / slug
        n = count_images(d) if d.is_dir() else 0
        status = "OK" if n >= args.min_per_class else "LOW"
        print(f"[{status}] {slug}: {n} images")
        if n < args.min_per_class:
            bad.append((slug, n))

    if bad:
        raise SystemExit(
            f"\n{len(bad)} class(es) below {args.min_per_class}. "
            "Collect more images before splitting."
        )
    print("\nAll classes meet the minimum.")


if __name__ == "__main__":
    main()
