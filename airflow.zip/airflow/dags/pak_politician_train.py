"""
Optional Airflow DAG: runs `dvc repro train_models` on the worker.

Setup:
  1. Copy this file (or symlink repo `airflow/dags/`) into your Airflow `dags/` folder.
  2. Airflow UI → Admin → Variables → add `project2_root` = absolute path to this repo on the worker.
  3. Worker image must include: Python, dvc, git, project deps (`pip install -r requirements.txt`).
"""
from __future__ import annotations

from datetime import datetime

from airflow import DAG
from airflow.operators.bash import BashOperator

with DAG(
    dag_id="pak_politician_dvc_train",
    default_args={"owner": "mlops", "retries": 0},
    description="DVC stage train_models for Pakistani public-figures CNN (Project 2).",
    schedule_interval=None,
    start_date=datetime(2024, 1, 1),
    catchup=False,
    tags=["project2", "dvc", "optional"],
) as dag:
    BashOperator(
        task_id="dvc_repro_train_models",
        bash_command=r"""
set -euo pipefail
cd "{{ var.value.get('project2_root', '/opt/mlops-pak-politician') }}"
export PATH="${HOME}/.local/bin:${PATH}"
command -v dvc >/dev/null 2>&1 || { echo "dvc not found on PATH"; exit 1; }
dvc repro train_models
""",
    )
