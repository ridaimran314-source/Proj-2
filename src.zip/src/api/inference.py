from __future__ import annotations

import io
from pathlib import Path

import torch
from PIL import Image
from torchvision import transforms

from politician_cnn.data import eval_transforms
from politician_cnn.models import create_model


def load_model(ckpt_path: Path, device: torch.device):
    try:
        ckpt = torch.load(ckpt_path, map_location=device, weights_only=False)
    except TypeError:
        ckpt = torch.load(ckpt_path, map_location=device)
    arch = ckpt["architecture"]
    class_names = ckpt["class_names"]
    model = create_model(str(arch), num_classes=len(class_names))
    model.load_state_dict(ckpt["model_state"])
    model.to(device)
    model.eval()
    return model, class_names, int(ckpt.get("image_size", 224))


@torch.no_grad()
def predict_image_bytes(
    model: torch.nn.Module,
    class_names: list[str],
    image_size: int,
    data: bytes,
    device: torch.device,
) -> tuple[str, dict[str, float]]:
    img = Image.open(io.BytesIO(data)).convert("RGB")
    tfm = eval_transforms(image_size)
    x = tfm(img).unsqueeze(0).to(device)
    logits = model(x)
    prob = torch.softmax(logits, dim=1)[0]
    idx = int(prob.argmax().item())
    scores = {class_names[i]: float(prob[i].item()) for i in range(len(class_names))}
    return class_names[idx], scores
