"""FastAPI app for CNN face-class inference (Docker / EC2)."""
from __future__ import annotations

import os
from pathlib import Path

import torch
from fastapi import FastAPI, File, HTTPException, UploadFile
from pydantic import BaseModel

from api.inference import load_model, predict_image_bytes

MODEL_PATH = Path(os.environ.get("MODEL_PATH", "artifacts/resnet50/best.pt")).resolve()

_device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
_model = None
_class_names: list[str] = []
_image_size = 224


def get_model():
    global _model, _class_names, _image_size
    if _model is None:
        if not MODEL_PATH.is_file():
            raise RuntimeError(
                f"Checkpoint not found: {MODEL_PATH}. "
                "Mount a trained best.pt or set MODEL_PATH."
            )
        _model, _class_names, _image_size = load_model(MODEL_PATH, _device)
    return _model, _class_names, _image_size


app = FastAPI(title="Pakistani public-figures CNN API", version="1.0.0")


class HealthResponse(BaseModel):
    status: str
    model_path: str
    device: str


class PredictResponse(BaseModel):
    predicted_class: str
    probabilities: dict[str, float]


@app.get("/health", response_model=HealthResponse)
def health():
    return HealthResponse(
        status="ok",
        model_path=str(MODEL_PATH),
        device=str(_device),
    )


@app.post("/predict", response_model=PredictResponse)
async def predict(file: UploadFile = File(..., description="Face image (JPEG/PNG)")):
    if not file.content_type or not file.content_type.startswith("image/"):
        raise HTTPException(400, "Upload an image file (image/*).")
    data = await file.read()
    if len(data) < 32:
        raise HTTPException(400, "Image too small or empty.")
    try:
        model, names, img_sz = get_model()
        pred, probs = predict_image_bytes(model, names, img_sz, data, _device)
    except Exception as e:
        raise HTTPException(500, str(e)) from e
    return PredictResponse(predicted_class=pred, probabilities=probs)
