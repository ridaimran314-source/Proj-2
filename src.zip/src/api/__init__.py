# FastAPI inference service (Category A deployment)
