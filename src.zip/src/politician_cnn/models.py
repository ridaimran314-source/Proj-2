from __future__ import annotations

import torch.nn as nn
from torchvision import models


def create_model(architecture: str, num_classes: int) -> nn.Module:
    """Load a pretrained torchvision CNN and replace the classifier head."""
    arch = architecture.lower().replace("-", "_")
    if arch == "resnet50":
        weights = models.ResNet50_Weights.IMAGENET1K_V2
        m = models.resnet50(weights=weights)
        in_f = m.fc.in_features
        m.fc = nn.Linear(in_f, num_classes)
        return m
    if arch == "resnet101":
        weights = models.ResNet101_Weights.IMAGENET1K_V2
        m = models.resnet101(weights=weights)
        in_f = m.fc.in_features
        m.fc = nn.Linear(in_f, num_classes)
        return m
    if arch == "resnet152":
        weights = models.ResNet152_Weights.IMAGENET1K_V2
        m = models.resnet152(weights=weights)
        in_f = m.fc.in_features
        m.fc = nn.Linear(in_f, num_classes)
        return m
    if arch == "efficientnet_b0":
        weights = models.EfficientNet_B0_Weights.IMAGENET1K_V1
        m = models.efficientnet_b0(weights=weights)
        in_f = m.classifier[1].in_features
        m.classifier[1] = nn.Linear(in_f, num_classes)
        return m
    if arch == "efficientnet_b1":
        weights = models.EfficientNet_B1_Weights.IMAGENET1K_V2
        m = models.efficientnet_b1(weights=weights)
        in_f = m.classifier[1].in_features
        m.classifier[1] = nn.Linear(in_f, num_classes)
        return m
    if arch == "efficientnet_b2":
        weights = models.EfficientNet_B2_Weights.IMAGENET1K_V1
        m = models.efficientnet_b2(weights=weights)
        in_f = m.classifier[1].in_features
        m.classifier[1] = nn.Linear(in_f, num_classes)
        return m
    if arch == "efficientnet_b3":
        weights = models.EfficientNet_B3_Weights.IMAGENET1K_V1
        m = models.efficientnet_b3(weights=weights)
        in_f = m.classifier[1].in_features
        m.classifier[1] = nn.Linear(in_f, num_classes)
        return m
    if arch == "efficientnet_b4":
        weights = models.EfficientNet_B4_Weights.IMAGENET1K_V1
        m = models.efficientnet_b4(weights=weights)
        in_f = m.classifier[1].in_features
        m.classifier[1] = nn.Linear(in_f, num_classes)
        return m
    if arch == "vgg16":
        weights = models.VGG16_Weights.IMAGENET1K_V1
        m = models.vgg16(weights=weights)
        in_f = m.classifier[6].in_features
        m.classifier[6] = nn.Linear(in_f, num_classes)
        return m
    if arch == "vgg19":
        weights = models.VGG19_Weights.IMAGENET1K_V1
        m = models.vgg19(weights=weights)
        in_f = m.classifier[6].in_features
        m.classifier[6] = nn.Linear(in_f, num_classes)
        return m
    raise ValueError(
        f"Unknown architecture {architecture!r}. "
        "Try: resnet50, resnet101, resnet152, efficientnet_b0–b4, vgg16, vgg19."
    )


def normalize_architecture(architecture: str) -> str:
    return architecture.lower().replace("-", "_")


def set_trainable_layers(model: nn.Module, architecture: str, *, head_only: bool) -> None:
    """Freeze/unfreeze parameters for transfer learning.

    - head_only=True: train only the classifier head (backbone frozen).
    - head_only=False: train all parameters.
    """
    arch = normalize_architecture(architecture)

    if not head_only:
        for p in model.parameters():
            p.requires_grad = True
        return

    for p in model.parameters():
        p.requires_grad = False

    if arch.startswith("resnet"):
        for p in model.fc.parameters():
            p.requires_grad = True
        return
    if arch.startswith("efficientnet"):
        for p in model.classifier.parameters():
            p.requires_grad = True
        return
    if arch.startswith("vgg"):
        for p in model.classifier.parameters():
            p.requires_grad = True
        return

    raise ValueError(f"Unsupported architecture for freezing: {architecture!r}")


def iter_trainable_parameters(model: nn.Module):
    for p in model.parameters():
        if p.requires_grad:
            yield p
