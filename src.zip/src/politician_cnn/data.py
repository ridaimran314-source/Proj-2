from __future__ import annotations

from pathlib import Path

import torch
from torch.utils.data import DataLoader
from torchvision import datasets, transforms


IMAGENET_MEAN = (0.485, 0.456, 0.406)
IMAGENET_STD = (0.229, 0.224, 0.225)


def train_transforms(image_size: int = 224) -> transforms.Compose:
    """Augmentation only for training (after split), per assignment."""
    return transforms.Compose(
        [
            transforms.RandomResizedCrop(image_size, scale=(0.75, 1.0)),
            transforms.RandomRotation(degrees=20),
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.ColorJitter(brightness=0.35, contrast=0.2, saturation=0.1, hue=0.05),
            transforms.RandomAffine(degrees=0, translate=(0.05, 0.05), scale=(0.9, 1.1)),
            transforms.ToTensor(),
            transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
        ]
    )


def eval_transforms(image_size: int = 224) -> transforms.Compose:
    return transforms.Compose(
        [
            transforms.Resize(int(image_size * 1.14)),
            transforms.CenterCrop(image_size),
            transforms.ToTensor(),
            transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
        ]
    )


class ImageFolderWithPaths(datasets.ImageFolder):
    def __getitem__(self, index: int):
        path, target = self.samples[index]
        sample, t = super().__getitem__(index)
        return sample, t, path


def make_loaders(
    data_root: Path,
    batch_size: int,
    num_workers: int,
    image_size: int = 224,
) -> tuple[DataLoader, DataLoader, DataLoader, list[str]]:
    train_dir = data_root / "train"
    val_dir = data_root / "val"
    test_dir = data_root / "test"
    for d, name in [(train_dir, "train"), (val_dir, "val"), (test_dir, "test")]:
        if not d.is_dir():
            raise FileNotFoundError(f"Missing {name} directory: {d}")

    train_set = ImageFolderWithPaths(str(train_dir), transform=train_transforms(image_size))
    val_set = datasets.ImageFolder(str(val_dir), transform=eval_transforms(image_size))
    test_set = ImageFolderWithPaths(str(test_dir), transform=eval_transforms(image_size))

    class_names = train_set.classes
    if val_set.classes != class_names or test_set.classes != class_names:
        raise ValueError("train/val/test class folders must match exactly (same names, same order).")

    pin = torch.cuda.is_available()
    train_loader = DataLoader(
        train_set,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=pin,
        persistent_workers=num_workers > 0,
    )
    val_loader = DataLoader(
        val_set,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=pin,
        persistent_workers=num_workers > 0,
    )
    test_loader = DataLoader(
        test_set,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=pin,
        persistent_workers=num_workers > 0,
    )
    return train_loader, val_loader, test_loader, class_names
