from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Sequence

import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import torch
import torch.nn as nn
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
)
from torch.utils.data import DataLoader
from tqdm import tqdm


@torch.no_grad()
def collect_predictions(
    model: nn.Module,
    loader: DataLoader,
    device: torch.device,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, list[str]]:
    """Returns y_true, y_pred, prob_of_predicted_class, paths."""
    model.eval()
    ys: list[int] = []
    preds: list[int] = []
    conf_wrong: list[float] = []
    paths_out: list[str] = []
    for batch in tqdm(loader, desc="test", leave=False):
        if len(batch) == 3:
            x, y, paths = batch
        else:
            x, y = batch
            paths = [""] * x.size(0)
        x = x.to(device, non_blocking=True)
        logits = model(x)
        prob = torch.softmax(logits, dim=1)
        pred = prob.argmax(dim=1)
        p_pred = prob[torch.arange(prob.size(0), device=device), pred]
        ys.extend(y.numpy().tolist())
        preds.extend(pred.cpu().numpy().tolist())
        conf_wrong.extend(p_pred.cpu().numpy().tolist())
        paths_out.extend(str(p) for p in paths)
    return (
        np.array(ys),
        np.array(preds),
        np.array(conf_wrong),
        paths_out,
    )


def plot_curves(
    history: dict[str, list[float]],
    out_path: Path,
    title: str,
) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    epochs = range(1, len(history["train_loss"]) + 1)
    fig, ax = plt.subplots(1, 2, figsize=(11, 4))
    ax[0].plot(epochs, history["train_loss"], label="train")
    ax[0].plot(epochs, history["val_loss"], label="val")
    ax[0].set_xlabel("Epoch")
    ax[0].set_ylabel("Loss")
    ax[0].set_title("Loss")
    ax[0].legend()
    ax[0].grid(True, alpha=0.3)
    ax[1].plot(epochs, history["train_acc"], label="train")
    ax[1].plot(epochs, history["val_acc"], label="val")
    ax[1].set_xlabel("Epoch")
    ax[1].set_ylabel("Accuracy")
    ax[1].set_title("Accuracy")
    ax[1].legend()
    ax[1].grid(True, alpha=0.3)
    fig.suptitle(title)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def plot_confusion_heatmap(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    class_names: Sequence[str],
    out_path: Path,
    title: str,
) -> None:
    cm = confusion_matrix(y_true, y_pred, labels=list(range(len(class_names))))
    fig, ax = plt.subplots(figsize=(max(10, len(class_names) * 0.5), max(8, len(class_names) * 0.45)))
    sns.heatmap(
        cm,
        annot=True,
        fmt="d",
        cmap="Blues",
        xticklabels=class_names,
        yticklabels=class_names,
        ax=ax,
    )
    ax.set_xlabel("Predicted")
    ax.set_ylabel("True")
    ax.set_title(title)
    plt.xticks(rotation=45, ha="right")
    plt.yticks(rotation=0)
    fig.tight_layout()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def save_top_misclassified(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    conf_pred: np.ndarray,
    paths: list[str],
    class_names: Sequence[str],
    out_dir: Path,
    k: int = 5,
) -> list[dict]:
    """Copy top-k wrong predictions by confidence in the predicted (wrong) class."""
    out_dir.mkdir(parents=True, exist_ok=True)
    mistakes: list[tuple[float, int, int, str]] = []
    for i in range(len(y_true)):
        if y_true[i] != y_pred[i]:
            mistakes.append((float(conf_pred[i]), int(y_true[i]), int(y_pred[i]), paths[i]))
    mistakes.sort(key=lambda t: -t[0])
    top = mistakes[:k]
    manifest: list[dict] = []
    for rank, (conf, yt, yp, src) in enumerate(top, start=1):
        if not src or not Path(src).is_file():
            manifest.append(
                {
                    "rank": rank,
                    "confidence_wrong_label": conf,
                    "true": class_names[yt],
                    "predicted": class_names[yp],
                    "source": src,
                    "note": "missing file",
                }
            )
            continue
        ext = Path(src).suffix or ".jpg"
        dest = out_dir / f"{rank:02d}_true-{class_names[yt]}_pred-{class_names[yp]}_p{conf:.3f}{ext}"
        shutil.copy2(src, dest)
        manifest.append(
            {
                "rank": rank,
                "confidence_wrong_label": conf,
                "true": class_names[yt],
                "predicted": class_names[yp],
                "source": src,
                "saved_as": str(dest),
            }
        )
    (out_dir / "top_misclassified.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def build_metrics_payload(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    class_names: Sequence[str],
) -> dict:
    acc = float(accuracy_score(y_true, y_pred))
    report = classification_report(
        y_true,
        y_pred,
        target_names=list(class_names),
        output_dict=True,
        zero_division=0,
    )
    per_class = {}
    for name in class_names:
        row = report.get(name)
        if row:
            per_class[name] = {
                "precision": row["precision"],
                "recall": row["recall"],
                "f1-score": row["f1-score"],
                "support": int(row["support"]),
            }
        else:
            per_class[name] = {
                "precision": 0.0,
                "recall": 0.0,
                "f1-score": 0.0,
                "support": 0,
                "note": "no test samples with this label",
            }
    return {
        "overall_accuracy": acc,
        "meets_90_percent_requirement": acc >= 0.90,
        "per_class": per_class,
        "macro_avg": report.get("macro avg"),
        "weighted_avg": report.get("weighted avg"),
    }
