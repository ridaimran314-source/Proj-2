"""Pakistani public-figures CNN training utilities."""
