from __future__ import annotations

import argparse
import json
import os
import sys
from collections import Counter
from pathlib import Path

# Allow `python src/politician_cnn/train.py` without PYTHONPATH.
_ROOT = Path(__file__).resolve().parents[2]
_SRC = _ROOT / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from politician_cnn.data import make_loaders
from politician_cnn.engine import evaluate, train_one_epoch
from politician_cnn.models import create_model, iter_trainable_parameters, set_trainable_layers
from politician_cnn.reporting import (
    build_metrics_payload,
    collect_predictions,
    plot_confusion_heatmap,
    plot_curves,
    save_top_misclassified,
)


def build_loss_fn(
    *,
    device: torch.device,
    num_classes: int,
    class_weights_mode: str,
    train_loader: DataLoader,
) -> nn.Module:
    if class_weights_mode not in {"auto", "none"}:
        raise ValueError("class_weights_mode must be 'auto' or 'none'")
    if class_weights_mode == "none":
        return nn.CrossEntropyLoss()

    ds = train_loader.dataset
    counts = Counter(int(t) for t in ds.targets)
    n = float(len(ds))
    w = torch.zeros(num_classes, dtype=torch.float32)
    for c in range(num_classes):
        cnt = counts.get(c, 0)
        if cnt > 0:
            w[c] = n / (num_classes * float(cnt))

    if not bool((w > 0).any()):
        return nn.CrossEntropyLoss()

    meanw = float(w[w > 0].mean())
    w[w <= 0] = meanw
    return nn.CrossEntropyLoss(weight=w.to(device))


def train_single_architecture(
    architecture: str,
    data_root: Path,
    out_dir: Path,
    epochs: int,
    batch_size: int,
    lr: float,
    num_workers: int,
    image_size: int,
    device: torch.device,
    mlflow_enabled: bool = False,
    backbone_freeze_epochs: int = 0,
    finetune_lr: float | None = None,
    class_weights_mode: str = "auto",
) -> dict:
    train_loader, val_loader, test_loader, class_names = make_loaders(
        data_root, batch_size=batch_size, num_workers=num_workers, image_size=image_size
    )
    num_classes = len(class_names)
    model = create_model(architecture, num_classes=num_classes).to(device)
    loss_fn = build_loss_fn(
        device=device,
        num_classes=num_classes,
        class_weights_mode=class_weights_mode,
        train_loader=train_loader,
    )
    scaler: torch.cuda.amp.GradScaler | None
    scaler = torch.cuda.amp.GradScaler() if device.type == "cuda" else None

    resolved_finetune_lr = float(finetune_lr) if finetune_lr is not None else float(lr) * 0.2

    if mlflow_enabled:
        import mlflow

        mlflow.log_params(
            {
                "architecture": architecture,
                "epochs": epochs,
                "batch_size": batch_size,
                "lr": lr,
                "finetune_lr": resolved_finetune_lr,
                "backbone_freeze_epochs": backbone_freeze_epochs,
                "class_weights": class_weights_mode,
                "num_workers": num_workers,
                "image_size": image_size,
                "num_classes": num_classes,
            }
        )

    history: dict[str, list[float]] = {
        "train_loss": [],
        "train_acc": [],
        "val_loss": [],
        "val_acc": [],
    }
    best_val = -1.0
    best_state: dict | None = None

    model_out = out_dir / architecture.lower()
    model_out.mkdir(parents=True, exist_ok=True)

    current_phase: str | None = None
    optimizer: torch.optim.Optimizer | None = None
    scheduler: torch.optim.lr_scheduler.LRScheduler | None = None

    for epoch in range(1, epochs + 1):
        phase = (
            "head"
            if backbone_freeze_epochs > 0 and epoch <= backbone_freeze_epochs
            else "full"
        )
        if phase != current_phase:
            current_phase = phase
            head_only = phase == "head"
            set_trainable_layers(model, architecture, head_only=head_only)

            if phase == "head":
                lr_now = lr
            else:
                lr_now = lr if backbone_freeze_epochs <= 0 else resolved_finetune_lr

            params = list(iter_trainable_parameters(model))
            if not params:
                raise RuntimeError(f"No trainable parameters for phase={phase!r} ({architecture})")

            optimizer = torch.optim.AdamW(params, lr=lr_now, weight_decay=0.02)

            if phase == "head":
                if backbone_freeze_epochs >= epochs:
                    t_max = max(epochs, 1)
                else:
                    t_max = max(backbone_freeze_epochs, 1)
            else:
                if backbone_freeze_epochs <= 0:
                    t_max = max(epochs, 1)
                else:
                    t_max = max(epochs - backbone_freeze_epochs, 1)

            scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=t_max)

        assert optimizer is not None and scheduler is not None

        tr_loss, tr_acc = train_one_epoch(
            model, train_loader, loss_fn, optimizer, device, scaler=scaler
        )
        va_loss, va_acc = evaluate(model, val_loader, loss_fn, device)
        scheduler.step()
        history["train_loss"].append(tr_loss)
        history["train_acc"].append(tr_acc)
        history["val_loss"].append(va_loss)
        history["val_acc"].append(va_acc)
        print(
            f"[{architecture}] epoch {epoch}/{epochs} phase={current_phase} "
            f"train_loss={tr_loss:.4f} acc={tr_acc:.4f} | val_loss={va_loss:.4f} acc={va_acc:.4f}"
        )
        if mlflow_enabled:
            import mlflow

            mlflow.log_metrics(
                {
                    "train_loss": tr_loss,
                    "train_accuracy": tr_acc,
                    "val_loss": va_loss,
                    "val_accuracy": va_acc,
                    "lr": float(optimizer.param_groups[0]["lr"]),
                },
                step=epoch,
            )
        if va_acc > best_val:
            best_val = va_acc
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}

    if best_state is not None:
        model.load_state_dict(best_state)
    ckpt_path = model_out / "best.pt"
    torch.save(
        {
            "architecture": architecture,
            "class_names": class_names,
            "num_classes": num_classes,
            "model_state": best_state or model.state_dict(),
            "val_accuracy": best_val,
            "image_size": image_size,
            "train_config": {
                "lr": lr,
                "finetune_lr": resolved_finetune_lr,
                "backbone_freeze_epochs": backbone_freeze_epochs,
                "class_weights": class_weights_mode,
            },
        },
        ckpt_path,
    )

    # Test evaluation + deliverables
    y_true, y_pred, conf_pred, paths = collect_predictions(model, test_loader, device)
    metrics = build_metrics_payload(y_true, y_pred, class_names)
    metrics["architecture"] = architecture
    metrics["best_val_accuracy"] = float(best_val)
    metrics["epochs_trained"] = epochs
    (model_out / "test_metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")

    plot_curves(history, model_out / "train_val_curves.png", title=f"{architecture} — training vs validation")
    plot_confusion_heatmap(
        y_true,
        y_pred,
        class_names,
        model_out / "confusion_matrix_heatmap.png",
        title=f"{architecture} — test confusion matrix",
    )
    save_top_misclassified(
        y_true,
        y_pred,
        conf_pred,
        paths,
        class_names,
        model_out / "top_misclassified",
        k=5,
    )

    if mlflow_enabled:
        import mlflow

        mlflow.log_metrics(
            {
                "test_accuracy": metrics["overall_accuracy"],
                "test_meets_90pct": float(metrics["meets_90_percent_requirement"]),
                "best_val_accuracy": float(best_val),
            }
        )
        for rel in (
            ckpt_path,
            model_out / "test_metrics.json",
            model_out / "train_val_curves.png",
            model_out / "confusion_matrix_heatmap.png",
            model_out / "top_misclassified" / "top_misclassified.json",
        ):
            p = Path(rel)
            if p.is_file():
                mlflow.log_artifact(str(p))
        try:
            mlflow.pytorch.log_model(model.cpu(), "torch_model")
            model.to(device)
        except Exception as e:
            print(f"[mlflow] log_model skipped: {e}")

    print(
        f"[{architecture}] test accuracy={metrics['overall_accuracy']:.4f} "
        f"(>=0.90 required: {metrics['meets_90_percent_requirement']})"
    )
    print(f"[{architecture}] saved checkpoint and reports under {model_out}")
    return metrics


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    root = Path(__file__).resolve().parents[2]
    p = argparse.ArgumentParser(description="Train pretrained CNNs on splits/train|val|test (ImageFolder).")
    p.add_argument("--data-root", type=Path, default=root / "splits")
    p.add_argument("--output-dir", type=Path, default=root / "artifacts")
    p.add_argument(
        "--models",
        nargs="+",
        default=["resnet50", "efficientnet_b0"],
        help="Architectures to train sequentially (min 2 for rubric).",
    )
    p.add_argument("--epochs", type=int, default=30)
    p.add_argument("--batch-size", type=int, default=16)
    p.add_argument("--lr", type=float, default=3e-4)
    p.add_argument(
        "--finetune-lr",
        type=float,
        default=None,
        help="Learning rate after unfreezing the backbone. Defaults to 0.2 * --lr.",
    )
    p.add_argument(
        "--backbone-freeze-epochs",
        type=int,
        default=8,
        help="Train only the classifier head for the first N epochs (backbone frozen). 0 disables freezing.",
    )
    p.add_argument(
        "--class-weights",
        choices=["auto", "none"],
        default="auto",
        help="If auto, reweight CrossEntropyLoss inversely to class frequency in the training split.",
    )
    p.add_argument("--num-workers", type=int, default=0)
    p.add_argument("--image-size", type=int, default=224)
    p.add_argument(
        "--no-mlflow",
        action="store_true",
        help="Disable MLflow experiment tracking (use in CI or offline smoke tests).",
    )
    p.add_argument(
        "--mlflow-experiment",
        default=os.environ.get("MLFLOW_EXPERIMENT_NAME", "pak_politician_cnn"),
    )
    p.add_argument(
        "--mlflow-tracking-uri",
        default=os.environ.get("MLFLOW_TRACKING_URI"),
        help="Defaults to file:./mlruns if unset.",
    )
    return p.parse_args(argv)


def main(argv: list[str] | None = None) -> None:
    args = parse_args(argv)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")
    if len(args.models) < 2:
        raise SystemExit("At least two --models are required for the assignment.")

    use_mlflow = not args.no_mlflow
    if use_mlflow:
        import mlflow

        uri = args.mlflow_tracking_uri or "file:./mlruns"
        mlflow.set_tracking_uri(uri)
        mlflow.set_experiment(args.mlflow_experiment)
        print(f"MLflow tracking URI: {uri}  experiment: {args.mlflow_experiment}")

    args.output_dir.mkdir(parents=True, exist_ok=True)
    summary: dict[str, dict] = {}

    if use_mlflow:
        import mlflow

        with mlflow.start_run(run_name="train_session"):
            mlflow.log_params(
                {
                    "models": " ".join(args.models),
                    "epochs": args.epochs,
                    "batch_size": args.batch_size,
                    "lr": args.lr,
                    "finetune_lr": args.finetune_lr,
                    "backbone_freeze_epochs": args.backbone_freeze_epochs,
                    "class_weights": args.class_weights,
                    "image_size": args.image_size,
                }
            )
            for arch in args.models:
                with mlflow.start_run(run_name=arch, nested=True):
                    summary[arch] = train_single_architecture(
                        arch,
                        data_root=args.data_root,
                        out_dir=args.output_dir,
                        epochs=args.epochs,
                        batch_size=args.batch_size,
                        lr=args.lr,
                        num_workers=args.num_workers,
                        image_size=args.image_size,
                        device=device,
                        mlflow_enabled=True,
                        backbone_freeze_epochs=args.backbone_freeze_epochs,
                        finetune_lr=args.finetune_lr,
                        class_weights_mode=args.class_weights,
                    )
            comp = args.output_dir / "comparison_summary.json"
            comp.write_text(json.dumps(summary, indent=2), encoding="utf-8")
            mlflow.log_artifact(str(comp))
    else:
        for arch in args.models:
            summary[arch] = train_single_architecture(
                arch,
                data_root=args.data_root,
                out_dir=args.output_dir,
                epochs=args.epochs,
                batch_size=args.batch_size,
                lr=args.lr,
                num_workers=args.num_workers,
                image_size=args.image_size,
                device=device,
                mlflow_enabled=False,
                backbone_freeze_epochs=args.backbone_freeze_epochs,
                finetune_lr=args.finetune_lr,
                class_weights_mode=args.class_weights,
            )
        (args.output_dir / "comparison_summary.json").write_text(
            json.dumps(summary, indent=2),
            encoding="utf-8",
        )

    print(f"Wrote comparison summary to {args.output_dir / 'comparison_summary.json'}")


if __name__ == "__main__":
    main()
