# EC2 deployment (Category A)

## 1. Launch instance

- **AMI:** Ubuntu Server 22.04 LTS (or 24.04)  
- **Instance type:** `t3.medium` or larger if you serve on CPU; GPU optional for inference.  
- **Security group:** inbound **TCP 8000** (or 80 behind a reverse proxy) from your IP or `0.0.0.0/0` for demos only.

## 2. Install Docker on the instance

```bash
sudo apt-get update
sudo apt-get install -y ca-certificates curl gnupg
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo $VERSION_CODENAME) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
sudo apt-get update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
sudo usermod -aG docker ubuntu
```

Log out and back in so `docker` works without `sudo` (or prefix `sudo` for all `docker` commands).

## 3. Copy the trained checkpoint

From your laptop (replace host and key path):

```bash
scp -i your-key.pem artifacts/resnet50/best.pt ubuntu@YOUR_PUBLIC_DNS:~/best.pt
```

## 4. Copy the API image or build on EC2

**Option A — build on EC2**

```bash
git clone https://github.com/YOUR_ORG/YOUR_REPO.git
cd YOUR_REPO
docker build -f docker/Dockerfile.api -t pak-politician-api .
```

**Option B — push to Docker Hub / ECR from your machine, then `docker pull` on EC2.**

## 5. Run the container

```bash
docker run -d --name pak-api --restart unless-stopped \
  -p 8000:8000 \
  -v /home/ubuntu/best.pt:/app/models/best.pt:ro \
  pak-politician-api
```

## 6. Verify

```bash
curl -s http://YOUR_PUBLIC_DNS:8000/health
curl -s -X POST http://YOUR_PUBLIC_DNS:8000/predict -F "file=@sample.jpg"
```

## 7. Report / demo

Capture the **public URL** `http://<dns>:8000` and screenshots of `/health` and a successful `/predict` response for your submission. For production, add HTTPS (Caddy, nginx, or AWS ALB) and restrict the security group.
