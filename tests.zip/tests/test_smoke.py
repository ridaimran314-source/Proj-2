from __future__ import annotations

import torch


def test_resnet_forward():
    from politician_cnn.models import create_model

    m = create_model("resnet50", num_classes=5)
    x = torch.randn(2, 3, 224, 224)
    y = m(x)
    assert y.shape == (2, 5)


def test_fastapi_app_import():
    import api.main as api_main

    assert api_main.app.title


def test_transfer_learning_head_only_resnet50():
    from politician_cnn.models import create_model, iter_trainable_parameters, set_trainable_layers

    m = create_model("resnet50", num_classes=7)
    set_trainable_layers(m, "resnet50", head_only=True)
    trainable = {id(p) for p in iter_trainable_parameters(m)}
    fc = {id(p) for p in m.fc.parameters()}
    assert trainable
    assert trainable.issubset(fc)

    set_trainable_layers(m, "resnet50", head_only=False)
    trainable_all = list(iter_trainable_parameters(m))
    assert len(trainable_all) > len(trainable)


def test_transfer_learning_head_only_efficientnet_b0():
    from politician_cnn.models import create_model, iter_trainable_parameters, set_trainable_layers

    m = create_model("efficientnet_b0", num_classes=7)
    set_trainable_layers(m, "efficientnet_b0", head_only=True)
    trainable = {id(p) for p in iter_trainable_parameters(m)}
    head = {id(p) for p in m.classifier.parameters()}
    assert trainable
    assert trainable.issubset(head)
